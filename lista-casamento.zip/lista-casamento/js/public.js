(function () {
  const $ = s => document.querySelector(s);
  let cfg = {}, itens = [], cat = 'Todos', busca = '', atual = null, pixCode = '';

  const FORMAS = {
    link: { t: 'Comprar pelo link da loja', d: 'Você compra online e confirma aqui.', ok: 'Confirmo que comprei este presente' },
    pessoalmente: { t: 'Comprar e entregar pessoalmente', d: 'Você leva o presente até os noivos.', ok: 'Confirmo que vou levar este presente' },
    pix: { t: 'Fazer um Pix do valor', d: 'Você envia o valor sugerido por Pix.', ok: 'Confirmo que fiz o Pix' }
  };

  function hero() {
    $('#nomes').textContent = cfg.nome_noivos || 'Lista de Presentes';
    document.title = (cfg.nome_noivos ? cfg.nome_noivos + ' · ' : '') + 'Lista de Presentes';
    $('#boas-vindas').textContent = cfg.mensagem_boas_vindas || '';
    if (cfg.data_casamento) {
      const [y, m, d] = cfg.data_casamento.split('-').map(Number);
      $('#data').textContent = new Date(y, m - 1, d).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
    }
  }

  function card(i) {
    const img = U.url(i.imagem_url);
    return `<article class="card">
      <div class="foto">${img ? `<img src="${U.esc(img)}" alt="${U.esc(i.titulo)}" loading="lazy">` : ''}</div>
      <div class="info">
        ${i.categoria ? `<span class="tag">${U.esc(i.categoria)}</span>` : ''}
        <h3>${U.esc(i.titulo)}</h3>
        <p class="desc">${U.esc(i.descricao)}</p>
        <p class="preco">${U.brl(i.preco)}</p>
        <button class="btn" data-id="${i.id}">Presentear</button>
      </div></article>`;
  }

  function render() {
    const cats = ['Todos', ...new Set(itens.map(i => i.categoria).filter(Boolean))];
    if (!cats.includes(cat)) cat = 'Todos';
    $('#chips').innerHTML = cats.map(c => `<button class="chip" aria-pressed="${c === cat}" data-c="${U.esc(c)}">${U.esc(c)}</button>`).join('');
    const q = U.plain(busca).toLowerCase();
    const lista = itens.filter(i => (cat === 'Todos' || i.categoria === cat) && (!q || U.plain(i.titulo).toLowerCase().includes(q)));
    $('#grid').innerHTML = lista.length ? lista.map(card).join('')
      : `<p class="vazio">${itens.length ? 'Nenhum presente encontrado. Tente outra busca ou categoria.' : 'Todos os presentes já foram escolhidos. Muito obrigado pelo carinho!'}</p>`;
  }

  async function carregar() {
    const [c, p] = await Promise.all([
      db.from('configuracoes').select('*').eq('id', 1).maybeSingle(),
      db.rpc('listar_presentes_disponiveis')
    ]);
    if (c.data) { cfg = c.data; hero(); }
    if (p.error) { $('#grid').innerHTML = '<p class="vazio">Não foi possível carregar a lista agora. Atualize a página em instantes.</p>'; return; }
    itens = p.data || []; render();
  }

  /* ---------- Modal ---------- */
  const modal = $('#modal'), corpo = $('#m-corpo');
  function abrir(item) { atual = item; telaEscolha(); modal.hidden = false; document.body.style.overflow = 'hidden'; modal.querySelector('.x').focus(); }
  function fechar() { modal.hidden = true; document.body.style.overflow = ''; atual = null; }

  function telaEscolha() {
    corpo.innerHTML = `<h2 id="m-titulo">${U.esc(atual.titulo)}</h2>
      <p class="preco">${U.brl(atual.preco)}</p>
      <p>Como você prefere presentear?</p>
      <div class="opts">${Object.entries(FORMAS).map(([k, f]) =>
        `<button class="opt" data-f="${k}"><strong>${f.t}</strong><span>${f.d}</span></button>`).join('')}</div>`;
  }

  function extra(forma) {
    if (forma === 'link') {
      const l = U.url(atual.link_loja);
      return l ? `<div class="box"><p class="hint">Compre no site da loja e depois volte aqui para confirmar.</p>
        <div class="row"><a class="btn" href="${U.esc(l)}" target="_blank" rel="noopener noreferrer">Abrir loja</a>
        <button type="button" class="btn sec" data-copy="${U.esc(l)}">Copiar link</button></div></div>`
        : `<div class="box"><p>Os noivos não cadastraram o link da loja para este item. Escolha outra forma de presentear.</p></div>`;
    }
    if (forma === 'pessoalmente') return `<div class="box"><p>Que ótimo! Preencha seus dados abaixo para avisarmos os noivos de que você vai levar <strong>${U.esc(atual.titulo)}</strong>.</p></div>`;
    pixCode = '';
    let qr = '';
    if (!cfg.chave_pix) return `<div class="box"><p>A chave Pix ainda não foi cadastrada. Escolha outra forma de presentear.</p></div>`;
    if (cfg.pix_nome && cfg.pix_cidade) {
      pixCode = U.pix(cfg.chave_pix.trim(), Number(atual.preco), cfg.pix_nome, cfg.pix_cidade);
      try { qr = `<img class="qr" src="${U.qr(pixCode)}" alt="QR Code Pix no valor de ${U.brl(atual.preco)}">`; } catch { }
    }
    if (!qr && U.url(cfg.qr_pix_url)) qr = `<img class="qr" src="${U.esc(U.url(cfg.qr_pix_url))}" alt="QR Code Pix">`;
    return `<div class="box center"><p>Valor sugerido: <strong>${U.brl(atual.preco)}</strong></p>${qr}
      <p class="chave">${U.esc(cfg.chave_pix)}</p>
      <div class="row"><button type="button" class="btn sec" data-copy="${U.esc(cfg.chave_pix)}">Copiar chave Pix</button>
      ${pixCode ? `<button type="button" class="btn sec" data-copy="${U.esc(pixCode)}">Copiar Pix copia e cola</button>` : ''}</div></div>`;
  }

  function telaForma(forma) {
    const f = FORMAS[forma];
    const bloqueado = (forma === 'link' && !U.url(atual.link_loja)) || (forma === 'pix' && !cfg.chave_pix);
    corpo.innerHTML = `<button class="voltar" type="button">‹ Voltar</button>
      <h2 id="m-titulo">${f.t}</h2>
      ${extra(forma)}
      <form id="f-res" data-f="${forma}" novalidate>
        <label>Nome completo<input name="nome" required autocomplete="name" maxlength="120"></label>
        <label>Telefone / WhatsApp (opcional)<input name="tel" type="tel" autocomplete="tel" maxlength="30"></label>
        <label>Mensagem para os noivos<textarea name="msg" rows="3" maxlength="1000" placeholder="Escreva um recado carinhoso"></textarea></label>
        <input name="site" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <p class="erro" role="alert"></p>
        <button class="btn grande" ${bloqueado ? 'disabled' : ''}>${f.ok}</button>
      </form>`;
  }

  function telaObrigado() {
    corpo.innerHTML = `<div class="center obrigado"><h2 id="m-titulo">Muito obrigado!</h2>
      <p>Seu presente foi registrado e os noivos receberão o seu recado com muito carinho.</p>
      <button class="btn" data-fechar>Voltar à lista</button></div>`;
  }

  async function enviar(form) {
    const erro = form.querySelector('.erro'), btn = form.querySelector('.btn');
    erro.textContent = '';
    if (form.site.value) return;
    const nome = form.nome.value.trim();
    if (nome.length < 3) { erro.textContent = 'Informe seu nome completo.'; form.nome.focus(); return; }
    btn.disabled = true; btn.textContent = 'Confirmando…';
    const { data, error } = await db.rpc('reservar_presente', {
      p_presente_id: atual.id, p_nome: nome, p_telefone: form.tel.value.trim(),
      p_forma: form.dataset.f, p_mensagem: form.msg.value.trim()
    });
    if (!error && data && data.ok) {
      itens = itens.filter(i => i.id !== atual.id); render(); telaObrigado(); return;
    }
    btn.disabled = false; btn.textContent = FORMAS[form.dataset.f].ok;
    if (data && data.erro === 'ja_reservado') {
      erro.textContent = 'Alguém acabou de escolher este presente. Escolha outro da lista.';
      itens = itens.filter(i => i.id !== atual.id); render();
    } else erro.textContent = 'Não foi possível confirmar agora. Tente novamente.';
  }

  /* ---------- Eventos ---------- */
  $('#grid').addEventListener('click', e => {
    const b = e.target.closest('[data-id]'); if (b) abrir(itens.find(i => i.id === b.dataset.id));
  });
  $('#chips').addEventListener('click', e => { const b = e.target.closest('[data-c]'); if (b) { cat = b.dataset.c; render(); } });
  $('#busca').addEventListener('input', e => { busca = e.target.value; render(); });
  modal.addEventListener('click', e => {
    if (e.target === modal || e.target.closest('.x') || e.target.closest('[data-fechar]')) return fechar();
    const o = e.target.closest('.opt'); if (o) return telaForma(o.dataset.f);
    if (e.target.closest('.voltar')) return telaEscolha();
    const c = e.target.closest('[data-copy]'); if (c) U.copy(c.dataset.copy);
  });
  modal.addEventListener('submit', e => { e.preventDefault(); enviar(e.target); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) fechar(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) carregar(); });
  setInterval(() => { if (modal.hidden) carregar(); }, 30000);

  carregar();
})();
