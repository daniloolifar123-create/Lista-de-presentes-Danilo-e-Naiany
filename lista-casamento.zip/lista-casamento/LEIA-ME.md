# Lista de Presentes de Casamento

Site estático (HTML/CSS/JS puro, sem build) + Supabase (banco, login e fotos) — tudo no plano gratuito.

## Estrutura
```
lista-casamento/
├── index.html        # site público dos convidados
├── admin.html        # painel privado dos noivos (login)
├── css/style.css
├── js/
│   ├── config.js     # << você cola aqui URL e chave do Supabase
│   ├── util.js       # utilitários, Pix/QR Code
│   ├── public.js     # vitrine, filtros, modal e reserva
│   └── admin.js      # login, CRUD, recebidos, configurações
└── supabase/schema.sql   # tabelas, regras de segurança e funções
```

## 1) Configurar o Supabase (grátis)
1. Crie conta em https://supabase.com e clique em **New project** (escolha região South America).
2. Menu **SQL Editor > New query**, cole todo o conteúdo de `supabase/schema.sql` e clique em **Run**.
3. Menu **Authentication > Users > Add user > Create new user**: informe e-mail e senha dos noivos (marque "Auto Confirm User").
4. **IMPORTANTE:** em **Authentication > Sign In / Providers > Email**, desative **Allow new users to sign up**. Sem isso, qualquer pessoa poderia criar conta e acessar o painel.
5. Em **Project Settings > API**, copie a **Project URL** e a chave **anon public**. Cole em `js/config.js`.

## 2) Testar no computador
Abra um terminal na pasta e rode `python3 -m http.server 8000`, depois acesse http://localhost:8000 e http://localhost:8000/admin.html.

## 3) Publicar (grátis)
**Netlify (mais fácil):** acesse https://app.netlify.com/drop e arraste a pasta `lista-casamento` inteira. O site entra no ar na hora; depois você pode trocar o nome do endereço em *Site settings*.

**Vercel:** envie a pasta para um repositório no GitHub, em https://vercel.com clique em **Add New > Project**, importe o repositório e clique em **Deploy** (Framework: Other, sem build).

## 4) Primeiro uso
1. Entre em `seusite/admin.html` com o e-mail e senha criados.
2. Aba **Configurações**: nomes, data, mensagem, chave Pix, nome e cidade do recebedor (para o QR Code com valor saindo automático).
   Chaves de telefone devem ter o formato `+5511999999999`.
3. Aba **Presentes**: cadastre os itens (foto por URL ou upload).
4. Aba **Recebidos**: veja quem escolheu o quê. Use **Liberar presente novamente** se alguém desistir.

## Observações
- Quando alguém confirma, o item some para os demais. A lista dos convidados também se atualiza sozinha a cada 30 segundos e quando a aba volta ao foco. Se duas pessoas confirmarem ao mesmo tempo, o banco aceita só a primeira.
- Não há cobrança de Pix pelo site: o convidado paga no app do banco e confirma aqui. Confira os recebimentos no seu banco.
- Projetos gratuitos do Supabase pausam após cerca de 1 semana sem uso. Acesse o site de vez em quando ou reative em um clique no painel do Supabase.
- Não compartilhe a pasta com a senha dos noivos; a chave `anon` pode ficar pública.
