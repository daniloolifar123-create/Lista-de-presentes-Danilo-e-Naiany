(function () {
  const { SUPABASE_URL, SUPABASE_ANON_KEY } = window.APP_CONFIG;
  window.db = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

  function tlv(id, v) { return id + String(v.length).padStart(2, '0') + v; }
  function crc16(s) {
    let c = 0xFFFF;
    for (let i = 0; i < s.length; i++) {
      c ^= s.charCodeAt(i) << 8;
      for (let j = 0; j < 8; j++) c = (c & 0x8000) ? ((c << 1) ^ 0x1021) & 0xFFFF : (c << 1) & 0xFFFF;
    }
    return c.toString(16).toUpperCase().padStart(4, '0');
  }

  const U = window.U = {
    esc: s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    brl: n => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }),
    plain: s => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, ''),
    url(u) { try { const x = new URL(u); return ['http:', 'https:'].includes(x.protocol) ? x.href : ''; } catch { return ''; } },
    data: iso => new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }),
    async copy(t) {
      try { await navigator.clipboard.writeText(t); }
      catch { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); }
      U.toast('Copiado!');
    },
    toast(m) {
      const t = document.getElementById('toast'); if (!t) return;
      t.textContent = m; t.classList.add('on');
      clearTimeout(U._t); U._t = setTimeout(() => t.classList.remove('on'), 2400);
    },
    // Pix "copia e cola" com valor (padrão BR Code do Banco Central)
    pix(chave, valor, nome, cidade) {
      const conta = tlv('00', 'br.gov.bcb.pix') + tlv('01', chave);
      let p = tlv('00', '01') + tlv('01', '11') + tlv('26', conta) + tlv('52', '0000') + tlv('53', '986');
      if (valor > 0) p += tlv('54', Number(valor).toFixed(2));
      p += tlv('58', 'BR') + tlv('59', U.plain(nome).toUpperCase().slice(0, 25)) +
           tlv('60', U.plain(cidade).toUpperCase().slice(0, 15)) + tlv('62', tlv('05', '***'));
      p += '6304';
      return p + crc16(p);
    },
    qr(texto) {
      const q = qrcode(0, 'M'); q.addData(texto); q.make();
      return q.createDataURL(5, 2);
    }
  };
})();
