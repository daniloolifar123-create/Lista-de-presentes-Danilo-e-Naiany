// Cole aqui os dados do seu projeto Supabase (Project Settings > API).
// A chave "anon" é pública por design: a segurança vem das regras (RLS) do schema.sql.
window.APP_CONFIG = {
  SUPABASE_URL: "https://SEU-PROJETO.supabase.co",
  SUPABASE_ANON_KEY: "SUA-CHAVE-ANON-AQUI"
};
