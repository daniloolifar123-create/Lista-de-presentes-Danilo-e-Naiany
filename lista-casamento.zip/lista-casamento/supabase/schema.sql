-- Rode este arquivo inteiro no Supabase: SQL Editor > New query > Run

create table if not exists public.configuracoes (
  id int primary key default 1 check (id = 1),
  nome_noivos text default 'Ana & Pedro',
  data_casamento date,
  mensagem_boas_vindas text default 'Ficamos muito felizes em ter você nesse dia tão especial. Escolha um presente com carinho.',
  chave_pix text,
  pix_nome text,
  pix_cidade text,
  qr_pix_url text
);
insert into public.configuracoes (id) values (1) on conflict do nothing;

create table if not exists public.presentes (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descricao text,
  preco numeric(10,2) not null default 0,
  categoria text,
  imagem_url text,
  link_loja text,
  criado_em timestamptz not null default now()
);

create table if not exists public.reservas (
  id uuid primary key default gen_random_uuid(),
  presente_id uuid not null unique references public.presentes(id) on delete cascade,
  convidado_nome text not null,
  telefone text,
  forma text not null check (forma in ('link','pessoalmente','pix')),
  mensagem text,
  criado_em timestamptz not null default now()
);
-- "unique" em presente_id garante que dois convidados nunca reservem o mesmo item.

alter table public.configuracoes enable row level security;
alter table public.presentes enable row level security;
alter table public.reservas enable row level security;

-- Configurações: todos leem, só os noivos (logados) alteram
create policy "config_leitura" on public.configuracoes for select to anon, authenticated using (true);
create policy "config_admin" on public.configuracoes for all to authenticated using (true) with check (true);
-- Presentes e reservas: acesso direto só para os noivos (logados)
create policy "presentes_admin" on public.presentes for all to authenticated using (true) with check (true);
create policy "reservas_admin" on public.reservas for all to authenticated using (true) with check (true);

-- Convidados só enxergam presentes AINDA NÃO reservados (e nunca veem quem reservou)
create or replace function public.listar_presentes_disponiveis()
returns setof public.presentes language sql stable security definer set search_path = public as $$
  select p.* from public.presentes p
  where not exists (select 1 from public.reservas r where r.presente_id = p.id)
  order by p.criado_em desc;
$$;

-- Reserva atômica feita pelo convidado
create or replace function public.reservar_presente(
  p_presente_id uuid, p_nome text, p_telefone text, p_forma text, p_mensagem text
) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if p_forma not in ('link','pessoalmente','pix') then
    return jsonb_build_object('ok', false, 'erro', 'forma_invalida');
  end if;
  if length(trim(coalesce(p_nome, ''))) < 3 then
    return jsonb_build_object('ok', false, 'erro', 'nome_invalido');
  end if;
  if not exists (select 1 from public.presentes where id = p_presente_id) then
    return jsonb_build_object('ok', false, 'erro', 'nao_encontrado');
  end if;
  insert into public.reservas (presente_id, convidado_nome, telefone, forma, mensagem)
  values (p_presente_id, left(trim(p_nome), 120), left(trim(coalesce(p_telefone, '')), 30), p_forma, left(trim(coalesce(p_mensagem, '')), 1000));
  return jsonb_build_object('ok', true);
exception when unique_violation then
  return jsonb_build_object('ok', false, 'erro', 'ja_reservado');
end $$;

revoke all on function public.listar_presentes_disponiveis() from public;
revoke all on function public.reservar_presente(uuid, text, text, text, text) from public;
grant execute on function public.listar_presentes_disponiveis() to anon, authenticated;
grant execute on function public.reservar_presente(uuid, text, text, text, text) to anon, authenticated;

-- Armazenamento de imagens (fotos dos presentes e QR Code)
insert into storage.buckets (id, name, public) values ('imagens', 'imagens', true) on conflict do nothing;
create policy "imagens_upload" on storage.objects for insert to authenticated with check (bucket_id = 'imagens');
create policy "imagens_update" on storage.objects for update to authenticated using (bucket_id = 'imagens');
create policy "imagens_delete" on storage.objects for delete to authenticated using (bucket_id = 'imagens');
