(function () {
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  const FORMAS = { link: 'Link da loja', pessoalmente: 'Pessoalmente', pix: 'Pix' };
  let presentes = [], reservas = [], cfg = {};

  async function init() { const { data: { session } } = await db.auth.getSession(); session ? entrar() : sair(); }
  function entrar() { $('#login').hidden = true; $('#app').hidden = false; carregar(); }
  function sair() { $('#login').hidden = false; $('#app').hidden = true; }

  $('#f-login').onsubmit = async e => {
    e.preventDefault(); $('#login-erro').textContent = '';
    const { error } = await db.auth.signInWithPassword({ email: $('#email').value.trim(), password: $('#senha').value });
    if (error) $('#login-erro').textContent = 'E-mail ou senha incorretos.'; else entrar();
  };
  $('#btn-sair').onclick = async () => { await db.auth.signOut(); sair(); };

  $$('[data-tab]').forEach(b => b.onclick = () => {
    $$('[data-tab]').forEach(x => x.setAttribute('aria-selected', x === b));
    $$('.painel').forEach(p => p.hidden = p.id !== 'tab-' + b.dataset.tab);
  });

  async function carregar() {
    const [p, r, c] = await Promise.all([
      db.from('presentes').select('*').order('criado_em', { ascending: false }),
      db.from('reservas').select('*, presentes(titulo, preco)').order('criado_em', { ascending: false }),
      db.from('configuracoes').select('*').eq('id', 1).maybeSingle()
    ]);
    presentes = p.data || []; reservas = r.data || []; cfg = c.data || {};
    renderPresentes(); renderReservas(); preencherConfig();
  }

  /* ---------- Presentes ---------- */
  function renderPresentes() {
    const reservados = new Set(reservas.map(r => r.presente_id));
    $('#lista').innerHTML = presentes.length ? presentes.map(p => `
      <div class="linha">
        <div class="mini">${U.url(p.imagem_url) ? `<img src="${U.esc(U.url(p.imagem_url))}" alt="">` : ''}</div>
        <div class="txt"><strong>${U.esc(p.titulo)}</strong>
          <span>${U.brl(p.preco)}${p.categoria ? ' · ' + U.esc(p.categoria) : ''}</span>
          ${reservados.has(p.id) ? '<span class="tag">Reservado</span>' : ''}</div>
        <div class="acoes"><button class="btn sec" data-edit="${p.id}">Editar</button>
        <button class="btn sec perigo" data-del="${p.id}">Excluir</button></div>
      </div>`).join('') : '<p class="vazio">Nenhum presente ainda. Clique em “Novo presente”.</p>';
  }
  $('#lista').onclick = async e => {
    const ed = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
    if (ed) abrirForm(presentes.find(p => p.id === ed.dataset.edit));
    if (del) {
      const p = presentes.find(x => x.id === del.dataset.del);
      if (!confirm(`Excluir “${p.titulo}”? Se ele já tiver sido reservado, o registro da reserva também será apagado.`)) return;
      const { error } = await db.from('presentes').delete().eq('id', p.id);
      error ? alert('Erro ao excluir: ' + error.message) : carregar();
    }
  };
  $('#novo').onclick = () => abrirForm(null);
  $('#cancelar').onclick = () => $('#dlg').close();

  function abrirForm(p) {
    const f = $('#f-presente'); f.reset();
    f.id.value = p?.id || ''; $('#dlg-titulo').textContent = p ? 'Editar presente' : 'Novo presente';
    f.titulo.value = p?.titulo || ''; f.descricao.value = p?.descricao || ''; f.preco.value = p?.preco ?? '';
    f.categoria.value = p?.categoria || ''; f.imagem_url.value = p?.imagem_url || ''; f.link_loja.value = p?.link_loja || '';
    $('#dlg').showModal();
  }

  async function upload(file, pasta) {
    if (file.size > 5 * 1024 * 1024) throw new Error('A imagem deve ter no máximo 5 MB.');
    const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '');
    const path = `${pasta}/${crypto.randomUUID()}.${ext}`;
    const { error } = await db.storage.from('imagens').upload(path, file, { contentType: file.type });
    if (error) throw error;
    return db.storage.from('imagens').getPublicUrl(path).data.publicUrl;
  }

  $('#f-presente').onsubmit = async e => {
    e.preventDefault();
    const f = e.target, btn = $('#salvar'); btn.disabled = true; btn.textContent = 'Salvando…';
    try {
      let img = f.imagem_url.value.trim();
      if (f.arquivo.files[0]) img = await upload(f.arquivo.files[0], 'presentes');
      const row = {
        titulo: f.titulo.value.trim(), descricao: f.descricao.value.trim(), preco: f.preco.valueAsNumber || 0,
        categoria: f.categoria.value.trim() || null, imagem_url: img || null, link_loja: f.link_loja.value.trim() || null
      };
      const q = f.id.value ? db.from('presentes').update(row).eq('id', f.id.value) : db.from('presentes').insert(row);
      const { error } = await q; if (error) throw error;
      $('#dlg').close(); carregar();
    } catch (err) { alert('Não foi possível salvar: ' + (err.message || err)); }
    btn.disabled = false; btn.textContent = 'Salvar presente';
  };

  /* ---------- Recebidos ---------- */
  function renderReservas() {
    $('#qtd-rec').textContent = reservas.length;
    $('#tb-rec').innerHTML = reservas.length ? reservas.map(r => `<tr>
      <td>${U.esc(r.presentes?.titulo || '—')}</td><td>${U.esc(r.convidado_nome)}</td><td>${U.esc(r.telefone || '—')}</td>
      <td>${FORMAS[r.forma] || ''}</td><td>${U.data(r.criado_em)}</td><td class="msg">${U.esc(r.mensagem || '—')}</td>
      <td><button class="btn sec perigo" data-lib="${r.id}">Liberar presente novamente</button></td></tr>`).join('')
      : '<tr><td colspan="7" class="vazio">Ainda não há presentes escolhidos.</td></tr>';
  }
  $('#tb-rec').onclick = async e => {
    const b = e.target.closest('[data-lib]'); if (!b) return;
    if (!confirm('Liberar este presente? Ele voltará a aparecer na lista para os convidados e o registro será apagado.')) return;
    const { error } = await db.from('reservas').delete().eq('id', b.dataset.lib);
    error ? alert('Erro: ' + error.message) : carregar();
  };

  /* ---------- Configurações ---------- */
  function preencherConfig() {
    const f = $('#f-config');
    f.nome_noivos.value = cfg.nome_noivos || ''; f.data_casamento.value = cfg.data_casamento || '';
    f.mensagem_boas_vindas.value = cfg.mensagem_boas_vindas || ''; f.chave_pix.value = cfg.chave_pix || '';
    f.pix_nome.value = cfg.pix_nome || ''; f.pix_cidade.value = cfg.pix_cidade || '';
    $('#qr-atual').innerHTML = U.url(cfg.qr_pix_url) ? `<img src="${U.esc(U.url(cfg.qr_pix_url))}" alt="QR Code atual">` : '';
  }
  $('#f-config').onsubmit = async e => {
    e.preventDefault();
    const f = e.target, btn = $('#salvar-cfg'); btn.disabled = true; btn.textContent = 'Salvando…';
    try {
      let qr = cfg.qr_pix_url || null;
      if (f.qr.files[0]) qr = await upload(f.qr.files[0], 'pix');
      const row = {
        id: 1, nome_noivos: f.nome_noivos.value.trim(), data_casamento: f.data_casamento.value || null,
        mensagem_boas_vindas: f.mensagem_boas_vindas.value.trim(), chave_pix: f.chave_pix.value.trim() || null,
        pix_nome: f.pix_nome.value.trim() || null, pix_cidade: f.pix_cidade.value.trim() || null, qr_pix_url: qr
      };
      const { error } = await db.from('configuracoes').upsert(row); if (error) throw error;
      U.toast('Configurações salvas'); carregar();
    } catch (err) { alert('Não foi possível salvar: ' + (err.message || err)); }
    btn.disabled = false; btn.textContent = 'Salvar configurações';
  };

  init();
})();
